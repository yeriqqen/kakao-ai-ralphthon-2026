# How we used Codex

The team set the intended users, language choices, simulated-call scope, and acceptance requirements. Codex implemented the customer chat, dynamic OpenAI routing, a separate Korean Realtime business screen, shared call state, and evidence preservation while keeping the earlier v1 work separate.

Codex split work across the customer interface, conversation logic, business audio, and submission evidence. The team checked expected behavior against observed results. Customer authorization and business acceptance are distinct steps. The active indicator depends on an actual connected state. Unknown personal information must return to the customer instead of receiving an invented answer.

A reproducible customer UI harness supplied explicitly synthetic API responses to check language selection, authorization, connection indicators, relay rendering, incomplete endings, recommendation reasoning, and failures. Its twenty checks passed. The report explicitly excludes real API, microphone, and audio verification. The current broader checkpoint has 63 local tests, 23 actual local HTTP checks with synthetic setup plans and upstream network blocked, and 14 mocked business browser checks passed. Passing those checks does not establish a successful live conversation.

The most useful verification finding came from a real laptop microphone rehearsal. The assistant collected four Korean business answers and read them back, but the business’s confirmation reset the answers to unresolved and triggered repeated questions. The teammate ended the run. Codex then added stricter readback evidence and preserved answer snapshots through confirmation. The correction requires another actual microphone rehearsal before the team can claim that failure is fixed in practice.

The startup revision waits for session, remote-track and connection readiness before a tool-free opening. It holds the microphone through permitted playback and fails explicitly if no opening audio arrives within 12 seconds. Mocked browser checks cover these gates, but the new opening still needs actual audibility verification.

A second verification cycle found that free-prose recommendations could strengthen an uncertain price and invent a comparison even after model review. Codex changed the interface so real AI selects an allowed advice action and references to existing answers; the app preserves those answer words when rendering the result. A saved third-call regression passed 9/9 checks using one real provider request, preserving the interrupted outcome and “may exceed 100,000 KRW.” That replay did not capture new audio.

Real language checks also found unsupported institution claims and loss of meaning between customer information and Korean questions. Some checks prompted targeted repairs, while remaining fidelity limitations are disclosed. Codex’s generated output was treated as something to inspect, not as proof of correctness.

The team must judge whether YOKOBU helps its intended users. No actual target-user feedback has been collected, so value remains **Unverified**. This explanation includes no raw prompts or Codex session logs.
